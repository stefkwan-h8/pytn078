from flask import Flask, render_template, request
app = Flask(__name__)

import numpy as np
import pickle
model = pickle.load(open('model/gaussian_nba.pkl', 'rb'))

@app.route('/report')
def report():
    return render_template('report.html')

@app.route('/', methods=["GET"])
def hasil():
    return render_template('index.html')

@app.route('/', methods=["POST"])
def predict():
    int_features = [int(x) for x in request.form.values()]
    final_features = [np.array(int_features)]

    if (final_features[0][0] == final_features[0][1]):
        return render_template('index.html', hasil = "jangan pilih tim yang sama sebagai team dan opponent")
    else:
        prediction = model.predict(final_features)[0]

        output = {0: 'Lose', 1: 'Win'}
        teams = ['ANA', 'AND', 'ATL', 'BAL', 'BLB', 'BOS', 'BRK', 'BUF', 'CAP',
                'CAR', 'CHA', 'CHH', 'CHI', 'CHO', 'CHP', 'CHS', 'CHZ', 'CIN',
                'CLE', 'CLR', 'DAL', 'DEN', 'DET', 'DLC', 'DNA', 'DNN', 'DNR',
                'DTF', 'FLO', 'FTW', 'GSW', 'HOU', 'HSM', 'INA', 'IND', 'INJ',
                'INO', 'KCK', 'KCO', 'KEN', 'LAC', 'LAL', 'LAS', 'MEM', 'MIA',
                'MIL', 'MIN', 'MLH', 'MMF', 'MMP', 'MMS', 'MMT', 'MNL', 'MNM',
                'MNP', 'NJA', 'NJN', 'NOB', 'NOH', 'NOJ', 'NOK', 'NOP', 'NYA',
                'NYK', 'NYN', 'OAK', 'OKC', 'ORL', 'PHI', 'PHO', 'PHW', 'PIT',
                'POR', 'PRO', 'PTC', 'PTP', 'ROC', 'SAA', 'SAC', 'SAS', 'SDA',
                'SDC', 'SDR', 'SDS', 'SEA', 'SFW', 'SHE', 'SSL', 'STB', 'STL',
                'SYR', 'TEX', 'TOR', 'TRH', 'TRI', 'UTA', 'UTS', 'VAN', 'VIR',
                'WAS', 'WAT', 'WSA', 'WSB', 'WSC']
        locations = ["Away", "Home", "Neutral"]
        
        str_hasil = (str(teams[final_features[0][0]]) + " lawan " 
                    + str(teams[final_features[0][1]]) + " di "
                    + str(locations[final_features[0][2]]) + " prediksi adalah: "
                    + str(output[prediction])
                    )

        return render_template('index.html', hasil = str_hasil)

